from pandac.PandaModules import *

class Goal():

    def __init__(self, game, name, yPosition):

        self.model = game.loader.loadModel("models/goal")
        self.model.reparentTo(render)
        self.model.setScale(.025, .05, .03)
        self.model.setX(.2)
        self.model.setY(yPosition)

        self.colTubeBottom = CollisionTube(-350, 0, 50, 350, 0, 50, 50)
        self.colNode = self.model.attachNewNode(CollisionNode('goal' + name))
        self.colNode.node().addSolid(self.colTubeBottom)
        self.colTubeTop = CollisionTube(-350, 0, 200, 350, 0, 200, 50)
        self.colNode = self.model.attachNewNode(CollisionNode('goal' + name))
        self.colNode.node().addSolid(self.colTubeTop)
#        self.colNode.show()
