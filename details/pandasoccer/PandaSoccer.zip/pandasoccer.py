from direct.showbase.ShowBase import ShowBase
from ball                     import Ball
from field                    import Field
from goal                     import Goal
from hud                      import Hud
from menu                     import Menu
from network                  import Network, NetworkClient, NetworkServer
from pandac.PandaModules      import *
from physics                  import Physics
from player                   import Player
import sys

class Game(ShowBase):

    def __init__(self):
        ShowBase.__init__(self)

        self.menu = Menu(self)

        self.server = None
        self.client = None

        self.colliders = {}
        self.lastPosition = 1

        self.playerColor = None
        self.playerIndex = None
        self.teams = {}

        self.started = False

    def addOtherPlayer(self):
        color = "Red"
        if len(self.teams["Red"]) > len(self.teams["Blue"]):
            color = "Blue"

        position = Player.POSITIONS[self.lastPosition]
        self.lastPosition += 1

        player = Player(self.ball, color, position[0], position[1])
        self.teams[color].append(player)
        player.index = len(self.teams[color]) - 1

        self.traverser.addCollider(player.colNode, self.queue)
        self.colliders[player.colNode] = player

        return player

    def joinServer(self):
        self.client  = NetworkClient(self, self.menu.ip)
        self.physics = Physics()
        self.ball    = Ball(self)

    def resetPositions(self):
        self.ball.resetPosition()

        for color in ("Blue", "Red"):
            for player in self.teams[color]:
                player.resetPosition()

    def setClientKeys(self):
        color = self.player.color
        index = self.player.index

        self.accept("a", self.client.sendPlayerInput, [color, index, Player.LEFT,    1])
        self.accept("d", self.client.sendPlayerInput, [color, index, Player.RIGHT,   1])
        self.accept("w", self.client.sendPlayerInput, [color, index, Player.ADVANCE, 1])

        self.accept("a-up", self.client.sendPlayerInput, [color, index, Player.LEFT,    0])
        self.accept("d-up", self.client.sendPlayerInput, [color, index, Player.RIGHT,   0])
        self.accept("w-up", self.client.sendPlayerInput, [color, index, Player.ADVANCE, 0])

        self.accept("space", self.client.sendPlayerKick, [color, index, Network.MESSAGE_PLAYER_KICK])

        self.accept("escape", sys.exit)

    def setServerKeys(self):
        self.accept("a", self.player.setInput, [Player.LEFT,    1])
        self.accept("d", self.player.setInput, [Player.RIGHT,   1])
        self.accept("w", self.player.setInput, [Player.ADVANCE, 1])

        self.accept("a-up", self.player.setInput, [Player.LEFT,    0])
        self.accept("d-up", self.player.setInput, [Player.RIGHT,   0])
        self.accept("w-up", self.player.setInput, [Player.ADVANCE, 0])

        self.accept("space", self.player.kick)
        self.accept("escape", sys.exit)

    def setStatus(self, status):
        if self.started:
            self.ball.setPosQuat(status['ball_pos'], status['ball_quat'])

            for color in ("Blue", "Red"):
                for i in range(0, len(self.teams[color])):
                    player = self.teams[color][i]
                    player.setPos(status[color][i][0])
                    player.setHpr(status[color][i][1])

                    if player.isMoving != status[color][i][2]:
                        if player.isMoving:
                            player.setAnimationStop()
                        else:
                            player.setAnimationMoving()

    def start(self):
        self.menu.hide()

        self.score = {
            "goalBlue" : 0,
            "goalRed"  : 0
        }

        self.hud = Hud(self.score)
        self.field = Field(self)

        self.goals = {
            "Blue" : Goal(self, "Blue", 87),
            "Red"  : Goal(self, "Red", -90)
        }

        base.disableMouse()

    def startClient(self):
        self.start()

        self.setClientKeys()

        taskMgr.add(self.updateScene, "updateScene")
        self.physics.start(self.ball)

        self.started = True

    def startServer(self):
        self.server = NetworkServer(self)

        self.physics = Physics()

        self.ball   = Ball(self)

        position = Player.POSITIONS[0]
        self.player = Player(self.ball, "Red", position[0], position[1])

        self.teams = {
            "Blue" : [],
            "Red"  : [self.player]
        }

        self.start()

        self.queue = CollisionHandlerQueue()
        self.traverser = CollisionTraverser()
        self.traverser.addCollider(self.player.colNode, self.queue)
        self.traverser.addCollider(self.ball.colNode, self.queue)
#        self.traverser.showCollisions(render)

        self.colliders[self.player.colNode] = self.player

        self.setServerKeys()

        taskMgr.add(self.updateScene, "updateScene")
        self.physics.start(self.ball)

        self.started = True

    def updateScene(self, task):

        for team in (self.teams['Red'], self.teams['Blue']):
            for player in team:
                player.update()

        if self.server:
            for team in (self.teams['Red'], self.teams['Blue']):
                for player in team:
                    player.updateAnimation()

        self.player.updateCamera()

        inRange = {}
        for color in ("Blue", "Red"):
            for player in self.teams[color]:
                inRange[player] = False

        if self.server:
            self.traverser.traverse(render)

            for i in range(self.queue.getNumEntries()):
                entry = self.queue.getEntry(i)
                fromName = entry.getFromNodePath().getName()
                intoName = entry.getIntoNodePath().getName()

                if fromName == "playerNode":
                    if intoName == "ballNode":
                        player = self.colliders[entry.getFromNodePath()]
                        inRange[player] = True

                    elif intoName == "goalBlue" or intoName == "goalRed" or intoName == "playerNode":
                        pass
                    else: #it's a boundary
                        self.colliders[entry.getFromNodePath()].retrocede()
                elif fromName == "ballNode":
                    if intoName == "playerNode":
                        pass
                    elif intoName == "goalBlue" or intoName == "goalRed":
                        self.score[intoName] += 1
                        self.server.sendHudUpdate(self.score)
                        self.hud.update()
                        self.resetPositions()
                    else: #it's a boundary
                        self.field.collide(self.ball, intoName)

            for player in inRange.keys():
                if inRange[player] != player.inRange:
                    player.setInRange(inRange[player])

        return task.cont

    def updateTeams(self, status):
        if self.teams:
            for color in ("Blue", "Red"):
                for i in range(0, len(self.teams[color])):
                    player = self.teams[color][i]
                    player.removeNode()
                    self.teams[color][i] = None

        self.teams = {
            "Blue" : [],
            "Red"  : []
        }

        for color in ("Blue", "Red"):
            for i in range(0, status[color + "_count"]):
                player = Player(self.ball, color, status[color][i][0], status[color][i][1])
                player.index = status[color][i][3]
                self.teams[color].append(player)

        if self.playerIndex == None:
            self.player = self.teams[status['color']][len(self.teams[status['color']]) - 1]
            self.playerIndex = self.player.index
            self.playerColor = self.player.color
        else:
            self.player = self.teams[self.playerColor][self.playerIndex]

game = Game()
game.run()
