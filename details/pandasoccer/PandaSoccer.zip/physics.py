from pandac.PandaModules import *

class Physics(OdeWorld):

    def __init__(self):
        OdeWorld.__init__(self)

        self.setGravity(0, 0, -9.81)

        self.initSurfaceTable(1)
        self.setSurfaceEntry(0, 0, 150, 0.5, 3, 0.9, 0.00001, 0.0, 0.002)

        self.space = OdeSimpleSpace()
        self.space.setAutoCollideWorld(self)
        self.contactGroup = OdeJointGroup()
        self.space.setAutoCollideJointGroup(self.contactGroup)

        self.deltaTimeAccumulator = 0.0
        self.stepSize = 1.0 / 90.0

    def start(self, ball):
        self.ball = ball
        taskMgr.doMethodLater(.1, self.taskPhysics, "taskPhysics")

    def taskPhysics(self, task):
        self.deltaTimeAccumulator += globalClock.getDt()

        while self.deltaTimeAccumulator > self.stepSize:
            self.deltaTimeAccumulator -= self.stepSize
            self.space.autoCollide()
            self.quickStep(self.stepSize)
            self.contactGroup.empty()

        self.ball.update()

        return task.cont
