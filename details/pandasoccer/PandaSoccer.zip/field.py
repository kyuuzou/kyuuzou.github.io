from pandac.PandaModules import *

class Field():

    def __init__(self, game):

        self.model = game.loader.loadModel("models/field")
        self.model.reparentTo(render)
        self.model.setScale(.1, .1, 1)

        self.geom = OdePlaneGeom(game.physics.space, Vec4(0, 0, 1, 0))

        self.boundaries = {}
        self.addBoundary("boundaryRight",  Vec3(1, 0, 0),  Point3(-500, 0, 0),  (1,  0), (-1, 1))
        self.addBoundary("boundaryLeft",   Vec3(-1, 0, 0), Point3(500, 0, 0),   (-1, 0), (-1, 1))
        self.addBoundary("boundaryBottom", Vec3(0, -1, 0), Point3(0, 1000, 0),  (0, -1), (1, -1))
        self.addBoundary("boundaryTop",    Vec3(0, 1, 0),  Point3(0, -1000, 0), (0,  1), (1, -1))

    def addBoundary(self, name, orientation, position, posOffset, velMultiplier):
        boundary = CollisionPlane(Plane(orientation, position))
        boundary.setTangible(True)
        self.boundaries[name] = [boundary, posOffset, velMultiplier]
        colNode = self.model.attachNewNode(CollisionNode(name))
        colNode.node().addSolid(boundary)

    def collide(self, ball, boundaryName):
        vel = ball.body.getLinearVel()
        pos = ball.body.getPosition()

        b = self.boundaries[boundaryName]
        ball.body.setPosition(pos.getX() + b[1][0], pos.getY() + b[1][1], pos.getZ())
        ball.body.setLinearVel(VBase3(vel[0] * b[2][0], vel[1] * b[2][1], vel[2]))
