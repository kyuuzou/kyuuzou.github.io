from pandac.PandaModules import *

class Ball():

    def __init__(self, game):
        self.model = game.loader.loadModel("models/ball")

        self.model.reparentTo(render)
        self.model.setPos(0, 0, 5)
        self.model.setScale(.01)

        self.colSphere = CollisionSphere(0, 0, 0, 100)
        self.colNode = self.model.attachNewNode(CollisionNode('ballNode'))
        self.colNode.node().addSolid(self.colSphere)
#        self.colNode.show()

        self.body = OdeBody(game.physics)
        self.mass = OdeMass()
        self.mass.setSphere(260, .1)
        self.body.setMass(self.mass)
        self.body.setPosition(self.model.getPos(render))
        self.body.setQuaternion(self.model.getQuat(render))

        self.geom = OdeSphereGeom(game.physics.space, .8)
        self.geom.setBody(self.body)

    def getPosition(self):
        return self.body.getPosition()

    def getQuaternion(self):
        return self.body.getQuaternion()

    def resetPosition(self):
        self.body.setPosition(0, 0, 5)
        self.body.setLinearVel(0, 0, 0)

    def setPosQuat(self, position, quaternion):
        self.body.setPosition(position)
        self.body.setQuaternion(Quat(quaternion))

    def update(self):
        self.model.setPosQuat(render, self.body.getPosition(), Quat(self.body.getQuaternion()))

        vel = self.body.getLinearVel()
        if vel[2] < 0.1 and self.body.getPosition().getZ() < 0.9:
            if abs(vel[0]) > 0:
                vel[0] *= .9

            if abs(vel[1]) > 0:
                vel[1] *= .9

        self.body.setLinearVel(vel)
