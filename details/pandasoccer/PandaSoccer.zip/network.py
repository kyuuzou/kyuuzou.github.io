from direct.distributed.PyDatagram         import PyDatagram
from direct.distributed.PyDatagramIterator import PyDatagramIterator
from pandac.PandaModules                   import *

class Network():

    MESSAGE_TEST         = 1
    MESSAGE_NEW_CLIENT   = 2
    MESSAGE_GAME_STATUS  = 3
    MESSAGE_UPDATE_TEAMS = 4
    MESSAGE_PLAYER_INPUT = 5
    MESSAGE_PLAYER_KICK  = 6
    MESSAGE_HUD_UPDATE   = 7

    def __init__(self, game):
        self.game = game

        self.manager  = QueuedConnectionManager()
        self.listener = QueuedConnectionListener(self.manager, 0)
        self.reader   = QueuedConnectionReader(self.manager, 0)
        self.writer   = ConnectionWriter(self.manager, 0)

        self.port_address = 9099

        taskMgr.add(self.taskReaderPolling, "Poll the connection reader", -40)

    def addFloatArray(self, datagram, array):
        for i in range(0, len(array)):
            datagram.addFloat32(array[i])

    def getFloatTuple(self, iterator, length):
        array = []
        for i in range(0, length):
            array.append(iterator.getFloat32())

        return tuple(array)

    def taskReaderPolling(self, task):
        if self.reader.dataAvailable():
            datagram = NetDatagram()

            if self.reader.getData(datagram):
                self.receiveMessage(datagram)

        return task.cont

class NetworkClient(Network):

    def __init__(self, game, ip):
        Network.__init__(self, game)

        self.ip_address = ip

        timeout = 3000  # 3 seconds

        self.connection = self.manager.openTCPClientConnection(self.ip_address, self.port_address, timeout)
        if self.connection:
            self.reader.addConnection(self.connection)  # receive messages from server

        self.sendEmptyMessage(Network.MESSAGE_NEW_CLIENT)

    def receiveMessage(self, datagram):
        iterator = PyDatagramIterator(datagram)
        type = iterator.getUint8()

        if type == Network.MESSAGE_GAME_STATUS:
            status = {}
            status['ball_pos']  = self.getFloatTuple(iterator, 3)
            status['ball_quat'] = self.getFloatTuple(iterator, 4)

            self.receiveTeam(status, iterator, "Blue")
            self.receiveTeam(status, iterator, "Red")

            self.game.setStatus(status)

        elif type == Network.MESSAGE_UPDATE_TEAMS:

            status = {}
            self.receiveTeam(status, iterator, "Blue")
            self.receiveTeam(status, iterator, "Red")

            status['color'] = iterator.getString()

            self.game.updateTeams(status)

        elif type == Network.MESSAGE_HUD_UPDATE:
            self.game.score["goalBlue"] = iterator.getUint8()
            self.game.score["goalRed"]  = iterator.getUint8()

            self.game.hud.update()

        elif type == Network.MESSAGE_NEW_CLIENT:
            self.game.startClient()

    def receiveTeam(self, status, iterator, color):
        status[color + '_count'] = iterator.getUint8()
        status[color] = []
        for i in range(0, status[color + '_count']):
            player_pos = self.getFloatTuple(iterator, 3)
            player_hpr = self.getFloatTuple(iterator, 3)
            player_moving = iterator.getBool()
            player_index = iterator.getUint8()

            status[color].append([player_pos, player_hpr, player_moving, player_index])

    def sendEmptyMessage(self, type):
        datagram = PyDatagram()
        datagram.addUint8(type)

        self.writer.send(datagram, self.connection)

    def sendMessage(self, message, type):
        datagram = PyDatagram()
        datagram.addUint8(type)
        datagram.addString(message)

        self.writer.send(datagram, self.connection)

    def sendPlayerInput(self, color, index, key, value):
        datagram = PyDatagram()
        datagram.addUint8(Network.MESSAGE_PLAYER_INPUT)

        datagram.addString(color)
        datagram.addUint8(index)
        datagram.addUint8(key)
        datagram.addUint8(value)

        self.writer.send(datagram, self.connection)

    def sendPlayerKick(self, color, index, type):
        datagram = PyDatagram()
        datagram.addUint8(type)

        datagram.addString(color)
        datagram.addUint8(index)

        self.writer.send(datagram, self.connection)

class NetworkServer(Network):

    def __init__(self, game):
        Network.__init__(self, game)

        self.activeConnections = []

        backlog   = 1000
        tcpSocket = self.manager.openTCPServerRendezvous(self.port_address, backlog)

        self.listener.addConnection(tcpSocket)

        taskMgr.add(self.taskListenerPolling, "Poll the connection listener", -39)
        taskMgr.doMethodLater(.01, self.taskUpdateStatus, "Update status")

    def receiveMessage(self, datagram):
        iterator = PyDatagramIterator(datagram)
        type = iterator.getUint8()

        if type == Network.MESSAGE_TEST:
            message = iterator.getString()
            print "Server: Message received:", message

        elif type == Network.MESSAGE_NEW_CLIENT:
            player = self.game.addOtherPlayer()

            datagram = PyDatagram()
            datagram.addUint8(Network.MESSAGE_UPDATE_TEAMS)
            self.sendTeamStatus(datagram, "Blue")
            self.sendTeamStatus(datagram, "Red")
            datagram.addString(player.color)

            for connection in self.activeConnections:
                self.writer.send(datagram, connection)

            self.sendEmptyMessage(Network.MESSAGE_NEW_CLIENT)

            self.sendHudUpdate(self.game.score)

        elif type == Network.MESSAGE_PLAYER_INPUT:
            color = iterator.getString()
            index = iterator.getUint8()
            key   = iterator.getUint8()
            value = iterator.getUint8()

            self.game.teams[color][index].setInput(key, value)

        elif type == Network.MESSAGE_PLAYER_KICK:
            color = iterator.getString()
            index = iterator.getUint8()

            self.game.teams[color][index].kick()

    def sendEmptyMessage(self, type):
        datagram = PyDatagram()
        datagram.addUint8(type)

        for connection in self.activeConnections:
            self.writer.send(datagram, connection)

    def sendGameStatus(self):
        datagram = PyDatagram()
        datagram.addUint8(Network.MESSAGE_GAME_STATUS)

        self.addFloatArray(datagram, self.game.ball.getPosition())
        self.addFloatArray(datagram, self.game.ball.getQuaternion())

        self.sendTeamStatus(datagram, "Blue")
        self.sendTeamStatus(datagram, "Red")

        for connection in self.activeConnections:
            self.writer.send(datagram, connection)

    def sendHudUpdate(self, score):
        datagram = PyDatagram()
        datagram.addUint8(Network.MESSAGE_HUD_UPDATE)

        datagram.addUint8(score["goalBlue"])
        datagram.addUint8(score["goalRed"])

        for connection in self.activeConnections:
            self.writer.send(datagram, connection)

    def sendTeamStatus(self, datagram, color):
        team = self.game.teams[color]
        datagram.addUint8(len(team))

        for player in team:
            self.addFloatArray(datagram, player.getPos())
            self.addFloatArray(datagram, player.getHpr())

            datagram.addBool(player.isMoving)
            datagram.addUint8(player.index)

    def taskListenerPolling(self, task):
        if self.listener.newConnectionAvailable():
            rendezvous = PointerToConnection()
            netAddress = NetAddress()
            newConnection = PointerToConnection()

            if self.listener.getNewConnection(rendezvous, netAddress, newConnection):
                newConnection = newConnection.p()
                self.activeConnections.append(newConnection)
                self.reader.addConnection(newConnection) # Begin reading connection

        return task.cont

    def taskUpdateStatus(self, task):
        self.sendGameStatus()

        return task.again


