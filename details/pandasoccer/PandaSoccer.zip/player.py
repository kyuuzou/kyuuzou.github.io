from direct.actor.Actor  import Actor
from pandac.PandaModules import *
import math

class Player(Actor):
    ADVANCE = 1
    RIGHT   = 2
    LEFT    = 3

    POSITIONS = [
        [(6, 10, 0),    (-30,  0, 0)],
        [(-6, -10, 0),  (-210, 0, 0)],
        [(12, 10, 0),   (-30,  0, 0)],
        [(-12, -10, 0), (-210, 0, 0)],
        [(6, 20, 0),    (-30,  0, 0)],
        [(-6, -20, 0),  (-210, 0, 0)],
        [(12, 20, 0),   (-30,  0, 0)],
        [(-12, -20, 0), (-210, 0, 0)]
    ]

    def __init__(self, ball, color, basePos, baseHpr):
        Actor.__init__(self, "models/" + color + "ralph", {"run":"models/ralph-run", "walk":"models/ralph-walk"})

        self.ball = ball
        self.color = color
        self.index = 0

        self.keys = {
            Player.ADVANCE : 0,
            Player.RIGHT   : 0,
            Player.LEFT    : 0
        }

        self.basePos = basePos
        self.baseHpr = baseHpr

        self.reparentTo(render)
        self.resetPosition()

        self.inRange = False
        self.isMoving = False

        self.colSphere = CollisionSphere(0, 0, 2.5, 3)
        self.colNode = self.attachNewNode(CollisionNode('playerNode'))
        self.colNode.node().addSolid(self.colSphere)
#        self.colNode.show()

    def advance(self):
        self.setY(self, -20 * globalClock.getDt())

    def isInRange(self):
        return self.inRange

    def kick(self):
        if self.isInRange():
            force = 2000
            angle = self.getH(render) - 90
            vector = Vec3(math.cos(math.radians(angle)), math.sin(math.radians(angle)), .5)
            self.ball.body.setForce(vector.getX() * force, vector.getY() * force, vector.getZ() * force)
            self.ball.body.setAngularVel(vector.getX() * 10, vector.getY() * 10, 0)

    def resetPosition(self):
        self.setPos(self.basePos)
        self.setHpr(self.baseHpr)

    def retrocede(self):
        self.setY(self, 20 * globalClock.getDt())

    def setAnimationMoving(self):
        self.isMoving = 1
        self.loop("run")

    def setAnimationStop(self):
        self.isMoving = 0
        self.stop()
        self.pose("walk", 5)

    def setInput(self, key, value):
        self.keys[key] = value

    def setInRange(self, inRange):
        self.inRange = inRange

    def turnLeft(self):
        self.setH(self.getH() + 300 * globalClock.getDt())

    def turnRight(self):
        self.setH(self.getH() - 300 * globalClock.getDt())

    def update(self):
        if self.keys[Player.LEFT]:
            self.turnLeft()
        if self.keys[Player.RIGHT]:
            self.turnRight()
        if self.keys[Player.ADVANCE]:
            self.advance()

    def updateAnimation(self):
        if self.keys[Player.ADVANCE] or self.keys[Player.LEFT] or self.keys[Player.RIGHT]:
            if not self.isMoving:
                self.setAnimationMoving()
        elif self.isMoving:
            self.setAnimationStop()

    def updateCamera(self):
        base.cam.setPos(self.getX(), self.getY() + 60, self.getZ() + 55)
        base.cam.lookAt(self)
