from direct.gui.OnscreenText import OnscreenText
from pandac.PandaModules     import *

class Hud():

    def __init__(self, score):

        self.score = score

        self.textScore = OnscreenText(
            text  = "Red Team   0 - 0   Blue Team",
            style = 1,
            fg    = (1,1,1,1),
            pos   = (0, 0.90),
            align = TextNode.ACenter,
            scale = .07
        )

        self.addInstructions(-0.75, "[W]: Run forward")
        self.addInstructions(-0.80, "[A]: Turn left")
        self.addInstructions(-0.85, "[D]: Turn right")
        self.addInstructions(-0.90, "[SPACE]: Kick ball")
        self.addInstructions(-0.95, "[ESC]: Quit")

    def addInstructions(self, position, message):
        return OnscreenText(
            text  = message,
            style = 1,
            fg    = (1,1,1,1),
            pos   = (.85, position),
            align = TextNode.ALeft,
            scale = .05
        )

    def update(self):
        self.textScore.setText(
            "Red Team   " + str(self.score["goalRed"]) + " - "
            + str(self.score["goalBlue"]) + "   Blue Team"
        )

